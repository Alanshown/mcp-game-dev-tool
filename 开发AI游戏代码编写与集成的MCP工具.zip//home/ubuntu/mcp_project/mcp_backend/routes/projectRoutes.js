const express = require('express');
const router = express.Router();
const projectService = require('../services/projectService');

// 创建新项目
router.post('/create', async (req, res) => {
  try {
    const projectData = req.body;
    const project = await projectService.createProject(projectData);
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取项目列表
router.get('/list', async (req, res) => {
  try {
    const projects = await projectService.getProjects();
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取项目详情
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const project = await projectService.getProjectById(id);
    res.json(project);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 保存项目配置
router.post('/config', async (req, res) => {
  try {
    const config = req.body;
    await projectService.saveProjectConfig(config);
    res.json({ message: '项目配置已保存' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 保存项目需求
router.post('/requirements', async (req, res) => {
  try {
    const requirements = req.body;
    await projectService.saveRequirements(requirements);
    res.json({ message: '项目需求已保存' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 运行项目
router.post('/run', async (req, res) => {
  try {
    const result = await projectService.runProject();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取项目状态
router.get('/status/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const status = await projectService.getProjectStatus(id);
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
