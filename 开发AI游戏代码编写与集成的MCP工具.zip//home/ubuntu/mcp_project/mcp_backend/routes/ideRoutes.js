const express = require('express');
const router = express.Router();
const ideService = require('../services/ideService');

// 获取可用的IDE列表
router.get('/list', async (req, res) => {
  try {
    const ides = await ideService.getAvailableIDEs();
    res.json(ides);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 启动指定的IDE
router.post('/launch', async (req, res) => {
  try {
    const { ideName, projectPath } = req.body;
    const result = await ideService.launchIDE(ideName, projectPath);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 在IDE中创建文件
router.post('/create-file', async (req, res) => {
  try {
    const { filePath, content } = req.body;
    await ideService.createFile(filePath, content);
    res.json({ message: '文件已创建' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 在IDE中修改文件
router.post('/edit-file', async (req, res) => {
  try {
    const { filePath, content } = req.body;
    await ideService.editFile(filePath, content);
    res.json({ message: '文件已修改' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 在IDE中删除文件
router.post('/delete-file', async (req, res) => {
  try {
    const { filePath } = req.body;
    await ideService.deleteFile(filePath);
    res.json({ message: '文件已删除' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 开始编码任务
router.post('/start-coding', async (req, res) => {
  try {
    const taskData = req.body;
    const result = await ideService.startCodingTask(taskData);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 暂停编码任务
router.post('/pause-coding', async (req, res) => {
  try {
    await ideService.pauseCodingTask();
    res.json({ message: '编码任务已暂停' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 完成编码任务
router.post('/complete-coding', async (req, res) => {
  try {
    const result = await ideService.completeCodingTask();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取编码进度
router.get('/coding-progress', async (req, res) => {
  try {
    const progress = await ideService.getCodingProgress();
    res.json(progress);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
