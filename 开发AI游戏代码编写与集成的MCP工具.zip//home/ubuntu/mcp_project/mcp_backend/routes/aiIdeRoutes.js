const express = require('express');
const router = express.Router();
const aiIdeIntegration = require('../services/aiIdeIntegration');

// 初始化AI-IDE集成会话
router.post('/init-session', async (req, res) => {
  try {
    const { projectId, ideName } = req.body;
    const result = await aiIdeIntegration.initSession(projectId, ideName);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 生成游戏代码
router.post('/generate-code', async (req, res) => {
  try {
    const { requirements, language, fileName } = req.body;
    const result = await aiIdeIntegration.generateGameCode(requirements, language, fileName);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 修复代码错误
router.post('/fix-error', async (req, res) => {
  try {
    const { code, errorMessage, language, fileName } = req.body;
    const result = await aiIdeIntegration.fixCodeError(code, errorMessage, language, fileName);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 生成项目结构
router.post('/generate-structure', async (req, res) => {
  try {
    const { requirements, projectType } = req.body;
    const result = await aiIdeIntegration.generateProjectStructure(requirements, projectType);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 自动化IDE操作
router.post('/automate-operation', async (req, res) => {
  try {
    const { operation, params } = req.body;
    const result = await aiIdeIntegration.automateIdeOperation(operation, params);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 生成游戏资源描述
router.post('/generate-asset-descriptions', async (req, res) => {
  try {
    const { requirements } = req.body;
    const result = await aiIdeIntegration.generateAssetDescriptions(requirements);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取会话统计信息
router.get('/session-stats', async (req, res) => {
  try {
    const result = await aiIdeIntegration.getSessionStats();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 结束会话
router.post('/end-session', async (req, res) => {
  try {
    const result = await aiIdeIntegration.endSession();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
