const express = require('express');
const router = express.Router();
const projectManager = require('../services/projectManager');

// 创建新项目
router.post('/create', async (req, res) => {
  try {
    const projectData = req.body;
    const result = await projectManager.createProject(projectData);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 初始化项目
router.post('/initialize/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const initData = req.body;
    const result = await projectManager.initializeProject(id, initData);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 开始项目开发
router.post('/start-development/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { phase } = req.body;
    const result = await projectManager.startDevelopment(id, phase);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 暂停项目开发
router.post('/pause-development/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await projectManager.pauseDevelopment(id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 完成当前开发阶段
router.post('/complete-phase/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await projectManager.completePhase(id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 运行项目
router.post('/run/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await projectManager.runProject(id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 处理错误反馈
router.post('/feedback/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const feedback = req.body;
    const result = await projectManager.processFeedback(id, feedback);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取项目状态
router.get('/status/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await projectManager.getProjectStatus(id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 关闭项目
router.post('/close/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await projectManager.closeProject(id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
