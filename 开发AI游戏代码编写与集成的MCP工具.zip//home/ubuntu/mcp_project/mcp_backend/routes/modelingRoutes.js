const express = require('express');
const router = express.Router();
const modelingService = require('../services/modelingService');

// 获取可用的建模软件列表
router.get('/software-list', async (req, res) => {
  try {
    const software = await modelingService.getAvailableModelingSoftware();
    res.json(software);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 启动指定的建模软件
router.post('/launch', async (req, res) => {
  try {
    const { softwareName, projectPath } = req.body;
    const result = await modelingService.launchModelingSoftware(softwareName, projectPath);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 开始建模任务
router.post('/start-modeling', async (req, res) => {
  try {
    const taskData = req.body;
    const result = await modelingService.startModelingTask(taskData);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 暂停建模任务
router.post('/pause-modeling', async (req, res) => {
  try {
    await modelingService.pauseModelingTask();
    res.json({ message: '建模任务已暂停' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 完成建模任务
router.post('/complete-modeling', async (req, res) => {
  try {
    const result = await modelingService.completeModelingTask();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取建模进度
router.get('/modeling-progress', async (req, res) => {
  try {
    const progress = await modelingService.getModelingProgress();
    res.json(progress);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 导出模型文件
router.post('/export-model', async (req, res) => {
  try {
    const { format, destination } = req.body;
    const result = await modelingService.exportModel(format, destination);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 导入模型文件到项目
router.post('/import-model', async (req, res) => {
  try {
    const { modelPath, projectPath } = req.body;
    const result = await modelingService.importModelToProject(modelPath, projectPath);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
