const express = require('express');
const router = express.Router();
const aiService = require('../services/aiService');

// 获取AI模型列表
router.get('/models', async (req, res) => {
  try {
    const models = await aiService.getAvailableModels();
    res.json(models);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 保存API配置
router.post('/config', async (req, res) => {
  try {
    const config = req.body;
    await aiService.saveApiConfig(config);
    res.json({ message: 'API配置已保存' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 处理项目需求
router.post('/process-requirements', async (req, res) => {
  try {
    const requirements = req.body;
    const result = await aiService.processRequirements(requirements);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 处理用户反馈
router.post('/process-feedback', async (req, res) => {
  try {
    const feedback = req.body;
    const result = await aiService.processFeedback(feedback);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 生成代码
router.post('/generate-code', async (req, res) => {
  try {
    const { requirements, context } = req.body;
    const code = await aiService.generateCode(requirements, context);
    res.json({ code });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 分析错误
router.post('/analyze-error', async (req, res) => {
  try {
    const { error, context } = req.body;
    const analysis = await aiService.analyzeError(error, context);
    res.json(analysis);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
