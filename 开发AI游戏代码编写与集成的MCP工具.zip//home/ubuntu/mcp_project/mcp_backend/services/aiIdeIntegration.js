const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const { spawn, exec } = require('child_process');
const aiService = require('./aiService');

// 配置文件路径
const CONFIG_PATH = path.join(__dirname, '../config/ai-ide-integration.json');

// 确保配置目录存在
fs.ensureDirSync(path.dirname(CONFIG_PATH));

// 默认配置
const DEFAULT_CONFIG = {
  promptTemplates: {
    codeGeneration: "根据以下游戏需求，生成{language}代码：\n{requirements}\n\n请生成{fileName}文件的完整代码，确保代码可以正常运行。",
    codeRefactoring: "请重构以下{language}代码，提高其性能和可读性：\n```{language}\n{code}\n```",
    bugFix: "以下{language}代码存在bug：\n```{language}\n{code}\n```\n\n错误信息：{errorMessage}\n\n请修复这个bug并解释修复方案。"
  },
  supportedLanguages: ["javascript", "typescript", "python", "csharp", "cpp"],
  maxCodeLength: 10000,
  useCodeCompletion: true
};

// 初始化配置
if (!fs.existsSync(CONFIG_PATH)) {
  fs.writeJsonSync(CONFIG_PATH, DEFAULT_CONFIG, { spaces: 2 });
}

class AiIdeIntegration {
  constructor() {
    this.config = fs.existsSync(CONFIG_PATH) 
      ? fs.readJsonSync(CONFIG_PATH) 
      : DEFAULT_CONFIG;
    
    // 当前会话
    this.currentSession = null;
  }

  // 初始化AI-IDE集成会话
  async initSession(projectId, ideName) {
    try {
      this.currentSession = {
        id: `session_${Date.now()}`,
        projectId,
        ideName,
        startTime: new Date(),
        interactions: [],
        codeGenerated: 0,
        fileCount: 0
      };
      
      console.log(`初始化AI-IDE集成会话: ${this.currentSession.id}`);
      
      return {
        sessionId: this.currentSession.id,
        status: 'initialized'
      };
    } catch (error) {
      console.error('初始化AI-IDE集成会话时出错:', error);
      throw new Error(`初始化AI-IDE集成会话失败: ${error.message}`);
    }
  }

  // 生成游戏代码
  async generateGameCode(requirements, language, fileName) {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      console.log(`生成游戏代码: ${fileName}, 语言: ${language}`);
      
      // 使用模板构建提示
      const prompt = this.config.promptTemplates.codeGeneration
        .replace('{language}', language)
        .replace('{requirements}', JSON.stringify(requirements, null, 2))
        .replace('{fileName}', fileName);
      
      // 调用AI服务生成代码
      const response = await aiService.generateCode({ prompt, language }, { 
        sessionId: this.currentSession.id,
        additionalInfo: `文件名: ${fileName}`
      });
      
      // 记录交互
      this.currentSession.interactions.push({
        type: 'code_generation',
        timestamp: new Date(),
        fileName,
        language,
        codeLength: response.code.length
      });
      
      // 更新统计信息
      this.currentSession.codeGenerated += response.code.length;
      this.currentSession.fileCount++;
      
      return {
        code: response.code,
        explanation: response.explanation,
        fileName
      };
    } catch (error) {
      console.error('生成游戏代码时出错:', error);
      throw new Error(`生成游戏代码失败: ${error.message}`);
    }
  }

  // 分析并修复代码错误
  async fixCodeError(code, errorMessage, language, fileName) {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      console.log(`修复代码错误: ${fileName}, 语言: ${language}`);
      
      // 使用模板构建提示
      const prompt = this.config.promptTemplates.bugFix
        .replace('{language}', language)
        .replace('{code}', code)
        .replace('{errorMessage}', errorMessage);
      
      // 调用AI服务分析错误
      const response = await aiService.analyzeError(prompt, {
        sessionId: this.currentSession.id,
        code
      });
      
      // 记录交互
      this.currentSession.interactions.push({
        type: 'error_fix',
        timestamp: new Date(),
        fileName,
        language,
        errorMessage
      });
      
      // 提取修复后的代码
      const fixedCode = this._extractFixedCode(response.analysis, code);
      
      return {
        fixedCode,
        analysis: response.analysis,
        suggestions: response.fixSuggestion
      };
    } catch (error) {
      console.error('修复代码错误时出错:', error);
      throw new Error(`修复代码错误失败: ${error.message}`);
    }
  }

  // 生成项目结构
  async generateProjectStructure(requirements, projectType) {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      console.log(`生成项目结构: 类型=${projectType}`);
      
      // 构建提示
      const prompt = `请为以下游戏需求生成一个完整的${projectType}游戏项目结构：\n${JSON.stringify(requirements, null, 2)}\n\n请列出所有需要创建的文件和目录，以及每个文件的主要功能描述。`;
      
      // 调用AI服务生成项目结构
      const response = await aiService.processRequirements({
        prompt,
        projectType
      });
      
      // 解析项目结构
      const structure = this._parseProjectStructure(response.plan);
      
      // 记录交互
      this.currentSession.interactions.push({
        type: 'project_structure_generation',
        timestamp: new Date(),
        projectType,
        fileCount: structure.files.length,
        directoryCount: structure.directories.length
      });
      
      return structure;
    } catch (error) {
      console.error('生成项目结构时出错:', error);
      throw new Error(`生成项目结构失败: ${error.message}`);
    }
  }

  // 自动化IDE操作
  async automateIdeOperation(operation, params) {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      console.log(`自动化IDE操作: ${operation}`);
      
      // 根据操作类型执行不同的IDE操作
      switch (operation) {
        case 'create_file':
          return await this._createFile(params.filePath, params.content);
        
        case 'edit_file':
          return await this._editFile(params.filePath, params.content);
        
        case 'delete_file':
          return await this._deleteFile(params.filePath);
        
        case 'create_directory':
          return await this._createDirectory(params.dirPath);
        
        case 'run_command':
          return await this._runCommand(params.command, params.workingDir);
        
        default:
          throw new Error(`不支持的IDE操作: ${operation}`);
      }
    } catch (error) {
      console.error('自动化IDE操作时出错:', error);
      throw new Error(`自动化IDE操作失败: ${error.message}`);
    }
  }

  // 生成游戏资源描述
  async generateAssetDescriptions(requirements) {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      console.log(`生成游戏资源描述`);
      
      // 构建提示
      const prompt = `请为以下游戏需求生成详细的游戏资源描述：\n${JSON.stringify(requirements, null, 2)}\n\n请列出所有需要的图像、音频、模型等资源，并提供每个资源的详细描述。`;
      
      // 调用AI服务生成资源描述
      const response = await aiService.processRequirements({
        prompt
      });
      
      // 解析资源描述
      const assets = this._parseAssetDescriptions(response.plan);
      
      // 记录交互
      this.currentSession.interactions.push({
        type: 'asset_description_generation',
        timestamp: new Date(),
        assetCount: assets.length
      });
      
      return assets;
    } catch (error) {
      console.error('生成游戏资源描述时出错:', error);
      throw new Error(`生成游戏资源描述失败: ${error.message}`);
    }
  }

  // 获取会话统计信息
  async getSessionStats() {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      const duration = (new Date() - this.currentSession.startTime) / 1000; // 秒
      
      return {
        sessionId: this.currentSession.id,
        projectId: this.currentSession.projectId,
        ideName: this.currentSession.ideName,
        duration,
        interactionCount: this.currentSession.interactions.length,
        codeGenerated: this.currentSession.codeGenerated,
        fileCount: this.currentSession.fileCount,
        lastInteraction: this.currentSession.interactions.length > 0
          ? this.currentSession.interactions[this.currentSession.interactions.length - 1]
          : null
      };
    } catch (error) {
      console.error('获取会话统计信息时出错:', error);
      throw new Error(`获取会话统计信息失败: ${error.message}`);
    }
  }

  // 结束会话
  async endSession() {
    try {
      if (!this.currentSession) {
        throw new Error('未初始化AI-IDE集成会话');
      }
      
      console.log(`结束AI-IDE集成会话: ${this.currentSession.id}`);
      
      const stats = await this.getSessionStats();
      
      // 清理会话
      const endedSession = { ...this.currentSession };
      this.currentSession = null;
      
      return {
        sessionId: endedSession.id,
        stats
      };
    } catch (error) {
      console.error('结束会话时出错:', error);
      throw new Error(`结束会话失败: ${error.message}`);
    }
  }

  // 从AI响应中提取修复后的代码
  _extractFixedCode(analysis, originalCode) {
    // 尝试从分析中提取代码块
    const codeBlockRegex = /```(?:javascript|js|python|py|csharp|cs|cpp|c\+\+|java)?\n([\s\S]*?)\n```/g;
    
    let match;
    let fixedCode = '';
    
    while ((match = codeBlockRegex.exec(analysis)) !== null) {
      fixedCode = match[1];
    }
    
    // 如果没有找到代码块，返回原始代码
    return fixedCode || originalCode;
  }

  // 解析项目结构
  _parseProjectStructure(plan) {
    const structure = {
      directories: [],
      files: []
    };
    
    // 简单的解析逻辑，实际应该使用更复杂的解析
    const lines = plan.split('\n');
    
    for (const line of lines) {
      // 检测目录（通常以/结尾）
      if (line.includes('/') && !line.includes('.')) {
        const dirMatch = line.match(/[\/\w-]+\//);
        if (dirMatch) {
          structure.directories.push({
            path: dirMatch[0],
            description: line.replace(dirMatch[0], '').trim()
          });
        }
      }
      
      // 检测文件（包含扩展名）
      const fileMatch = line.match(/[\w-]+\.\w+/);
      if (fileMatch) {
        structure.files.push({
          name: fileMatch[0],
          description: line.replace(fileMatch[0], '').trim()
        });
      }
    }
    
    return structure;
  }

  // 解析资源描述
  _parseAssetDescriptions(plan) {
    const assets = [];
    
    // 简单的解析逻辑，实际应该使用更复杂的解析
    const lines = plan.split('\n');
    let currentCategory = '';
    
    for (const line of lines) {
      // 检测资源类别
      if (line.includes('图像') || line.includes('图片') || line.includes('Images')) {
        currentCategory = 'image';
        continue;
      } else if (line.includes('音频') || line.includes('音效') || line.includes('Audio')) {
        currentCategory = 'audio';
        continue;
      } else if (line.includes('模型') || line.includes('Models')) {
        currentCategory = '3d_model';
        continue;
      }
      
      // 检测资源项
      const assetMatch = line.match(/^[\d\.\-\*]\s+(.+?)[:：](.+)$/);
      if (assetMatch && currentCategory) {
        assets.push({
          category: currentCategory,
          name: assetMatch[1].trim(),
          description: assetMatch[2].trim()
        });
      }
    }
    
    return assets;
  }

  // 创建文件
  async _createFile(filePath, content) {
    try {
      // 确保目录存在
      await fs.ensureDir(path.dirname(filePath));
      
      // 写入文件内容
      await fs.writeFile(filePath, content);
      
      console.log(`创建文件: ${filePath}`);
      
      // 记录交互
      if (this.currentSession) {
        this.currentSession.interactions.push({
          type: 'file_creation',
          timestamp: new Date(),
          filePath,
          contentLength: content.length
        });
      }
      
      return { success: true, message: `文件已创建: ${filePath}` };
    } catch (error) {
      console.error('创建文件时出错:', error);
      throw error;
    }
  }

  // 编辑文件
  async _editFile(filePath, content) {
    try {
      // 确保文件存在
      if (!await fs.pathExists(filePath)) {
        throw new Error(`文件不存在: ${filePath}`);
      }
      
      // 写入文件内容
      await fs.writeFile(filePath, content);
      
      console.log(`编辑文件: ${filePath}`);
      
      // 记录交互
      if (this.currentSession) {
        this.currentSession.interactions.push({
          type: 'file_edit',
          timestamp: new Date(),
          filePath,
          contentLength: content.length
        });
      }
      
      return { success: true, message: `文件已编辑: ${filePath}` };
    } catch (error) {
      console.error('编辑文件时出错:', error);
      throw error;
    }
  }

  // 删除文件
  async _deleteFile(filePath) {
    try {
      // 确保文件存在
      if (!await fs.pathExists(filePath)) {
        throw new Error(`文件不存在: ${filePath}`);
      }
      
      // 删除文件
      await fs.remove(filePath);
      
      console.log(`删除文件: ${filePath}`);
      
      // 记录交互
      if (this.currentSession) {
        this.currentSession.interactions.push({
          type: 'file_deletion',
          timestamp: new Date(),
          filePath
        });
      }
      
      return { success: true, message: `文件已删除: ${filePath}` };
    } catch (error) {
      console.error('删除文件时出错:', error);
      throw error;
    }
  }

  // 创建目录
  async _createDirectory(dirPath) {
    try {
      // 创建目录
      await fs.ensureDir(dirPath);
      
      console.log(`创建目录: ${dirPath}`);
      
      // 记录交互
      if (this.currentSession) {
        this.currentSession.interactions.push({
          type: 'directory_creation',
          timestamp: new Date(),
          dirPath
        });
      }
      
      return { success: true, message: `目录已创建: ${dirPath}` };
    } catch (error) {
      console.error('创建目录时出错:', error);
      throw error;
    }
  }

  // 运行命令
  async _runCommand(command, workingDir) {
    return new Promise((resolve, reject) => {
      console.log(`运行命令: ${command}, 工作目录: ${workingDir}`);
      
      // 记录交互
      if (this.currentSession) {
        this.currentSession.interactions.push({
          type: 'command_execution',
          timestamp: new Date(),
          command,
          workingDir
        });
      }
      
      exec(command, { cwd: workingDir }, (error, stdout, stderr) => {
        if (error) {
          console.error(`命令执行错误: ${error.message}`);
          return reject(new Error(`命令执行失败: ${error.message}`));
        }
        
        resolve({
          success: true,
          stdout,
          stderr
        });
      });
    });
  }
}

module.exports = new AiIdeIntegration();
