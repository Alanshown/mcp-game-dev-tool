const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// 配置文件路径
const CONFIG_PATH = path.join(__dirname, '../config/ai-config.json');

// 确保配置目录存在
fs.ensureDirSync(path.dirname(CONFIG_PATH));

// 默认配置
const DEFAULT_CONFIG = {
  model: 'gpt-4',
  apiKey: '',
  temperature: 0.7,
  maxTokens: 4096,
  advancedMode: false,
  saveHistory: true
};

// 初始化配置
if (!fs.existsSync(CONFIG_PATH)) {
  fs.writeJsonSync(CONFIG_PATH, DEFAULT_CONFIG, { spaces: 2 });
}

class AiService {
  constructor() {
    this.config = fs.existsSync(CONFIG_PATH) 
      ? fs.readJsonSync(CONFIG_PATH) 
      : DEFAULT_CONFIG;
    
    // 会话历史记录
    this.sessionHistory = {};
  }

  // 获取可用的AI模型列表
  async getAvailableModels() {
    return [
      { id: 'gpt-4', name: 'GPT-4', provider: 'OpenAI' },
      { id: 'claude-3', name: 'Claude 3', provider: 'Anthropic' },
      { id: 'gemini-pro', name: 'Gemini Pro', provider: 'Google' },
      { id: 'llama-3', name: 'Llama 3', provider: 'Meta' }
    ];
  }

  // 保存API配置
  async saveApiConfig(config) {
    this.config = { ...this.config, ...config };
    await fs.writeJson(CONFIG_PATH, this.config, { spaces: 2 });
    return { success: true };
  }

  // 处理项目需求
  async processRequirements(requirements) {
    try {
      const sessionId = uuidv4();
      this.sessionHistory[sessionId] = [
        { role: 'system', content: '你是一个专业的游戏开发AI助手，负责帮助用户开发游戏项目。' },
        { role: 'user', content: `我需要开发一个游戏，详细需求如下：\n${JSON.stringify(requirements, null, 2)}` }
      ];

      const response = await this._callAiModel(sessionId);
      
      return {
        sessionId,
        plan: response,
        tasks: this._extractTasks(response)
      };
    } catch (error) {
      console.error('处理需求时出错:', error);
      throw new Error(`处理需求失败: ${error.message}`);
    }
  }

  // 处理用户反馈
  async processFeedback(feedback) {
    try {
      const { sessionId, content } = feedback;
      
      if (!this.sessionHistory[sessionId]) {
        this.sessionHistory[sessionId] = [
          { role: 'system', content: '你是一个专业的游戏开发AI助手，负责帮助用户开发游戏项目。' }
        ];
      }
      
      this.sessionHistory[sessionId].push({ role: 'user', content });
      const response = await this._callAiModel(sessionId);
      
      return {
        sessionId,
        response,
        actions: this._extractActions(response)
      };
    } catch (error) {
      console.error('处理反馈时出错:', error);
      throw new Error(`处理反馈失败: ${error.message}`);
    }
  }

  // 生成代码
  async generateCode(requirements, context) {
    try {
      const sessionId = context.sessionId || uuidv4();
      
      if (!this.sessionHistory[sessionId]) {
        this.sessionHistory[sessionId] = [
          { role: 'system', content: '你是一个专业的游戏开发AI助手，专注于编写高质量的游戏代码。' }
        ];
      }
      
      this.sessionHistory[sessionId].push({ 
        role: 'user', 
        content: `请根据以下需求生成游戏代码：\n${JSON.stringify(requirements, null, 2)}\n${context.additionalInfo || ''}` 
      });
      
      const response = await this._callAiModel(sessionId);
      
      // 提取代码块
      const code = this._extractCode(response);
      
      return {
        sessionId,
        code,
        explanation: this._extractExplanation(response)
      };
    } catch (error) {
      console.error('生成代码时出错:', error);
      throw new Error(`生成代码失败: ${error.message}`);
    }
  }

  // 分析错误
  async analyzeError(error, context) {
    try {
      const sessionId = context.sessionId || uuidv4();
      
      if (!this.sessionHistory[sessionId]) {
        this.sessionHistory[sessionId] = [
          { role: 'system', content: '你是一个专业的游戏开发AI助手，专注于分析和修复代码错误。' }
        ];
      }
      
      this.sessionHistory[sessionId].push({ 
        role: 'user', 
        content: `我的游戏代码出现了以下错误，请分析原因并提供修复方案：\n${error}\n${context.code || ''}` 
      });
      
      const response = await this._callAiModel(sessionId);
      
      return {
        sessionId,
        analysis: response,
        fixSuggestion: this._extractFixSuggestion(response)
      };
    } catch (error) {
      console.error('分析错误时出错:', error);
      throw new Error(`分析错误失败: ${error.message}`);
    }
  }

  // 调用AI模型
  async _callAiModel(sessionId) {
    try {
      // 这里是模拟调用AI模型的代码
      // 实际实现中，应该根据配置的模型和API密钥调用相应的API
      
      console.log(`调用AI模型: ${this.config.model}, 会话ID: ${sessionId}`);
      
      // 模拟API调用延迟
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 根据不同的模型返回不同的模拟响应
      const messages = this.sessionHistory[sessionId];
      const lastMessage = messages[messages.length - 1].content;
      
      let response = '';
      
      if (lastMessage.includes('需求')) {
        response = '我已分析了您的游戏需求，以下是开发计划：\n\n1. 设置基本游戏框架\n2. 实现核心游戏机制\n3. 添加游戏角色和交互\n4. 集成音效和视觉效果\n5. 测试和优化游戏性能';
      } else if (lastMessage.includes('错误')) {
        response = '分析：您的代码中存在语法错误，可能是由于缺少分号或括号不匹配导致的。\n\n修复建议：\n1. 检查第23行的括号匹配\n2. 在第45行添加缺失的分号\n3. 确保变量名称拼写正确';
      } else if (lastMessage.includes('生成')) {
        response = '```javascript\n// 游戏主类\nclass Game {\n  constructor() {\n    this.players = [];\n    this.isRunning = false;\n  }\n  \n  start() {\n    this.isRunning = true;\n    console.log("游戏开始");\n  }\n  \n  stop() {\n    this.isRunning = false;\n    console.log("游戏结束");\n  }\n}\n```\n\n这段代码创建了一个基本的游戏类，包含开始和结束游戏的方法。';
      } else {
        response = '我理解您的问题，让我来帮助解决。首先，我们需要分析当前情况，然后制定解决方案。建议按照以下步骤操作...';
      }
      
      // 保存AI响应到会话历史
      if (this.config.saveHistory) {
        this.sessionHistory[sessionId].push({ role: 'assistant', content: response });
      }
      
      return response;
    } catch (error) {
      console.error('调用AI模型时出错:', error);
      throw new Error(`调用AI模型失败: ${error.message}`);
    }
  }

  // 从AI响应中提取任务列表
  _extractTasks(response) {
    const tasks = [];
    const lines = response.split('\n');
    
    for (const line of lines) {
      const match = line.match(/^\d+\.\s+(.+)$/);
      if (match) {
        tasks.push({
          id: tasks.length + 1,
          description: match[1],
          completed: false
        });
      }
    }
    
    return tasks;
  }

  // 从AI响应中提取操作
  _extractActions(response) {
    // 简单实现，实际应该使用更复杂的解析逻辑
    const actions = [];
    
    if (response.includes('修复')) {
      actions.push({ type: 'fix', target: 'code' });
    }
    
    if (response.includes('添加')) {
      actions.push({ type: 'add', target: 'feature' });
    }
    
    if (response.includes('优化')) {
      actions.push({ type: 'optimize', target: 'performance' });
    }
    
    return actions;
  }

  // 从AI响应中提取代码
  _extractCode(response) {
    const codeBlocks = [];
    const regex = /```(?:javascript|js|python|py|csharp|cs|cpp|c\+\+|java)?\n([\s\S]*?)\n```/g;
    
    let match;
    while ((match = regex.exec(response)) !== null) {
      codeBlocks.push(match[1]);
    }
    
    return codeBlocks.join('\n\n');
  }

  // 从AI响应中提取解释
  _extractExplanation(response) {
    // 移除代码块，剩下的就是解释
    return response.replace(/```(?:javascript|js|python|py|csharp|cs|cpp|c\+\+|java)?\n[\s\S]*?\n```/g, '');
  }

  // 从AI响应中提取修复建议
  _extractFixSuggestion(response) {
    const suggestions = [];
    const lines = response.split('\n');
    
    let inSuggestionBlock = false;
    
    for (const line of lines) {
      if (line.includes('修复建议') || line.includes('解决方案')) {
        inSuggestionBlock = true;
        continue;
      }
      
      if (inSuggestionBlock && line.trim().length > 0) {
        suggestions.push(line.trim());
      }
    }
    
    return suggestions;
  }
}

module.exports = new AiService();
