const fs = require('fs-extra');
const path = require('path');
const { spawn, exec } = require('child_process');
const { v4: uuidv4 } = require('uuid');

// 配置文件路径
const CONFIG_PATH = path.join(__dirname, '../config/ide-config.json');

// 确保配置目录存在
fs.ensureDirSync(path.dirname(CONFIG_PATH));

// 默认配置
const DEFAULT_CONFIG = {
  defaultIDE: 'cursor',
  idePaths: {
    cursor: '/usr/bin/cursor',
    trea: '/usr/bin/trea',
    windsurf: '/usr/bin/windsurf',
    vscode: '/usr/bin/code'
  }
};

// 初始化配置
if (!fs.existsSync(CONFIG_PATH)) {
  fs.writeJsonSync(CONFIG_PATH, DEFAULT_CONFIG, { spaces: 2 });
}

class IdeService {
  constructor() {
    this.config = fs.existsSync(CONFIG_PATH) 
      ? fs.readJsonSync(CONFIG_PATH) 
      : DEFAULT_CONFIG;
    
    // 当前任务状态
    this.currentTask = null;
    this.taskProgress = 0;
    this.ideProcess = null;
  }

  // 获取可用的IDE列表
  async getAvailableIDEs() {
    return [
      { id: 'cursor', name: 'Cursor', path: this.config.idePaths.cursor },
      { id: 'trea', name: 'Trea', path: this.config.idePaths.trea },
      { id: 'windsurf', name: 'Windsurf', path: this.config.idePaths.windsurf },
      { id: 'vscode', name: 'Visual Studio Code', path: this.config.idePaths.vscode }
    ];
  }

  // 启动指定的IDE
  async launchIDE(ideName, projectPath) {
    try {
      const idePath = this.config.idePaths[ideName] || this.config.idePaths[this.config.defaultIDE];
      
      if (!idePath) {
        throw new Error(`未找到IDE: ${ideName}`);
      }
      
      // 确保项目路径存在
      await fs.ensureDir(projectPath);
      
      console.log(`启动IDE: ${idePath}, 项目路径: ${projectPath}`);
      
      // 在实际环境中，这里应该使用child_process启动IDE
      // 在沙盒环境中，我们模拟这个过程
      this.ideProcess = {
        id: uuidv4(),
        name: ideName,
        projectPath,
        status: 'running'
      };
      
      return {
        success: true,
        message: `已启动IDE: ${ideName}`,
        processId: this.ideProcess.id
      };
    } catch (error) {
      console.error('启动IDE时出错:', error);
      throw new Error(`启动IDE失败: ${error.message}`);
    }
  }

  // 在IDE中创建文件
  async createFile(filePath, content) {
    try {
      // 确保目录存在
      await fs.ensureDir(path.dirname(filePath));
      
      // 写入文件内容
      await fs.writeFile(filePath, content);
      
      console.log(`创建文件: ${filePath}`);
      
      return { success: true, message: `文件已创建: ${filePath}` };
    } catch (error) {
      console.error('创建文件时出错:', error);
      throw new Error(`创建文件失败: ${error.message}`);
    }
  }

  // 在IDE中修改文件
  async editFile(filePath, content) {
    try {
      // 确保文件存在
      if (!await fs.pathExists(filePath)) {
        throw new Error(`文件不存在: ${filePath}`);
      }
      
      // 写入文件内容
      await fs.writeFile(filePath, content);
      
      console.log(`修改文件: ${filePath}`);
      
      return { success: true, message: `文件已修改: ${filePath}` };
    } catch (error) {
      console.error('修改文件时出错:', error);
      throw new Error(`修改文件失败: ${error.message}`);
    }
  }

  // 在IDE中删除文件
  async deleteFile(filePath) {
    try {
      // 确保文件存在
      if (!await fs.pathExists(filePath)) {
        throw new Error(`文件不存在: ${filePath}`);
      }
      
      // 删除文件
      await fs.remove(filePath);
      
      console.log(`删除文件: ${filePath}`);
      
      return { success: true, message: `文件已删除: ${filePath}` };
    } catch (error) {
      console.error('删除文件时出错:', error);
      throw new Error(`删除文件失败: ${error.message}`);
    }
  }

  // 开始编码任务
  async startCodingTask(taskData) {
    try {
      const { ideName, projectPath, requirements } = taskData;
      
      // 启动IDE
      await this.launchIDE(ideName, projectPath);
      
      // 创建任务
      this.currentTask = {
        id: uuidv4(),
        type: 'coding',
        ideName,
        projectPath,
        requirements,
        status: 'running',
        startTime: new Date(),
        progress: 0
      };
      
      console.log(`开始编码任务: ${this.currentTask.id}`);
      
      // 模拟任务进度更新
      this._startProgressSimulation();
      
      return {
        success: true,
        taskId: this.currentTask.id,
        message: '编码任务已开始'
      };
    } catch (error) {
      console.error('开始编码任务时出错:', error);
      throw new Error(`开始编码任务失败: ${error.message}`);
    }
  }

  // 暂停编码任务
  async pauseCodingTask() {
    try {
      if (!this.currentTask) {
        throw new Error('没有正在进行的编码任务');
      }
      
      this.currentTask.status = 'paused';
      console.log(`暂停编码任务: ${this.currentTask.id}`);
      
      // 停止进度模拟
      this._stopProgressSimulation();
      
      return {
        success: true,
        message: '编码任务已暂停'
      };
    } catch (error) {
      console.error('暂停编码任务时出错:', error);
      throw new Error(`暂停编码任务失败: ${error.message}`);
    }
  }

  // 完成编码任务
  async completeCodingTask() {
    try {
      if (!this.currentTask) {
        throw new Error('没有正在进行的编码任务');
      }
      
      this.currentTask.status = 'completed';
      this.currentTask.progress = 100;
      this.currentTask.endTime = new Date();
      
      console.log(`完成编码任务: ${this.currentTask.id}`);
      
      // 停止进度模拟
      this._stopProgressSimulation();
      
      // 收集任务结果
      const result = {
        taskId: this.currentTask.id,
        ideName: this.currentTask.ideName,
        projectPath: this.currentTask.projectPath,
        duration: (this.currentTask.endTime - this.currentTask.startTime) / 1000, // 秒
        status: 'completed'
      };
      
      // 清理当前任务
      const completedTask = { ...this.currentTask };
      this.currentTask = null;
      
      return {
        success: true,
        message: '编码任务已完成',
        result
      };
    } catch (error) {
      console.error('完成编码任务时出错:', error);
      throw new Error(`完成编码任务失败: ${error.message}`);
    }
  }

  // 获取编码进度
  async getCodingProgress() {
    try {
      if (!this.currentTask) {
        return {
          status: 'no_task',
          progress: 0,
          message: '没有正在进行的编码任务'
        };
      }
      
      return {
        taskId: this.currentTask.id,
        status: this.currentTask.status,
        progress: this.currentTask.progress,
        startTime: this.currentTask.startTime,
        currentStep: this._getCurrentStep(),
        completed: this.currentTask.progress >= 100
      };
    } catch (error) {
      console.error('获取编码进度时出错:', error);
      throw new Error(`获取编码进度失败: ${error.message}`);
    }
  }

  // 模拟任务进度更新
  _startProgressSimulation() {
    // 清除可能存在的旧定时器
    this._stopProgressSimulation();
    
    // 创建新的进度更新定时器
    this.progressInterval = setInterval(() => {
      if (this.currentTask && this.currentTask.status === 'running') {
        // 增加进度，最大100
        this.currentTask.progress = Math.min(100, this.currentTask.progress + 5);
        
        console.log(`编码任务进度更新: ${this.currentTask.progress}%`);
        
        // 如果达到100%，自动完成任务
        if (this.currentTask.progress >= 100) {
          this.completeCodingTask().catch(console.error);
        }
      }
    }, 5000); // 每5秒更新一次
  }

  // 停止进度模拟
  _stopProgressSimulation() {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  }

  // 获取当前步骤描述
  _getCurrentStep() {
    if (!this.currentTask) return '';
    
    const progress = this.currentTask.progress;
    
    if (progress < 20) {
      return '初始化项目结构';
    } else if (progress < 40) {
      return '创建核心游戏类';
    } else if (progress < 60) {
      return '实现游戏逻辑';
    } else if (progress < 80) {
      return '添加用户界面';
    } else {
      return '优化和测试';
    }
  }
}

module.exports = new IdeService();
