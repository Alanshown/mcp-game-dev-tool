const fs = require('fs-extra');
const path = require('path');
const { spawn, exec } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const projectService = require('./projectService');
const ideService = require('./ideService');
const modelingService = require('./modelingService');
const aiIdeIntegration = require('./aiIdeIntegration');

// 配置文件路径
const CONFIG_PATH = path.join(__dirname, '../config/project-manager.json');

// 确保配置目录存在
fs.ensureDirSync(path.dirname(CONFIG_PATH));

// 默认配置
const DEFAULT_CONFIG = {
  projectsDir: path.join(__dirname, '../data/projects'),
  templatesDir: path.join(__dirname, '../templates'),
  maxConcurrentProjects: 5,
  autoSaveInterval: 60000, // 毫秒
  buildTimeout: 300000 // 毫秒
};

// 初始化配置
if (!fs.existsSync(CONFIG_PATH)) {
  fs.writeJsonSync(CONFIG_PATH, DEFAULT_CONFIG, { spaces: 2 });
}

class ProjectManager {
  constructor() {
    this.config = fs.existsSync(CONFIG_PATH) 
      ? fs.readJsonSync(CONFIG_PATH) 
      : DEFAULT_CONFIG;
    
    // 确保目录存在
    fs.ensureDirSync(this.config.projectsDir);
    fs.ensureDirSync(this.config.templatesDir);
    
    // 活动项目
    this.activeProjects = {};
    
    // 自动保存定时器
    this.autoSaveTimers = {};
  }

  // 创建新项目
  async createProject(projectData) {
    try {
      // 检查活动项目数量
      if (Object.keys(this.activeProjects).length >= this.config.maxConcurrentProjects) {
        throw new Error(`已达到最大并发项目数量: ${this.config.maxConcurrentProjects}`);
      }
      
      // 创建项目
      const project = await projectService.createProject(projectData);
      
      // 添加到活动项目
      this.activeProjects[project.id] = {
        id: project.id,
        name: project.name,
        type: project.type,
        status: 'initialized',
        createdAt: new Date(),
        lastActivity: new Date(),
        dir: project.dir
      };
      
      // 设置自动保存
      this._setupAutoSave(project.id);
      
      console.log(`项目管理器: 创建项目 ${project.id}`);
      
      return project;
    } catch (error) {
      console.error('创建项目时出错:', error);
      throw new Error(`创建项目失败: ${error.message}`);
    }
  }

  // 初始化项目
  async initializeProject(projectId, initData) {
    try {
      const { ideName, modelingSoftware, projectType, requirements } = initData;
      
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      // 更新项目状态
      project.status = 'initializing';
      project.lastActivity = new Date();
      
      console.log(`项目管理器: 初始化项目 ${projectId}`);
      
      // 初始化项目结构
      await this._initializeProjectStructure(projectId, projectType, requirements);
      
      // 初始化AI-IDE集成
      const sessionResult = await aiIdeIntegration.initSession(projectId, ideName);
      project.aiIdeSessionId = sessionResult.sessionId;
      
      // 生成项目结构
      const structure = await aiIdeIntegration.generateProjectStructure(requirements, projectType);
      
      // 创建项目文件和目录
      await this._createProjectFiles(projectId, structure);
      
      // 更新项目状态
      project.status = 'initialized';
      project.lastActivity = new Date();
      project.ideName = ideName;
      project.modelingSoftware = modelingSoftware;
      project.projectType = projectType;
      
      return {
        projectId,
        status: project.status,
        structure
      };
    } catch (error) {
      console.error('初始化项目时出错:', error);
      
      // 更新项目状态为错误
      if (this.activeProjects[projectId]) {
        this.activeProjects[projectId].status = 'error';
        this.activeProjects[projectId].lastError = error.message;
      }
      
      throw new Error(`初始化项目失败: ${error.message}`);
    }
  }

  // 开始项目开发
  async startDevelopment(projectId, phase) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      // 检查项目状态
      if (project.status !== 'initialized' && project.status !== 'paused') {
        throw new Error(`项目状态不允许开始开发: ${project.status}`);
      }
      
      // 更新项目状态
      project.status = 'developing';
      project.currentPhase = phase;
      project.lastActivity = new Date();
      
      console.log(`项目管理器: 开始项目开发 ${projectId}, 阶段: ${phase}`);
      
      if (phase === 'modeling') {
        // 启动建模软件
        const modelingResult = await modelingService.startModelingTask({
          softwareName: project.modelingSoftware,
          projectPath: project.dir,
          requirements: project.requirements
        });
        
        project.modelingTaskId = modelingResult.taskId;
      } else if (phase === 'coding') {
        // 启动IDE
        const codingResult = await ideService.startCodingTask({
          ideName: project.ideName,
          projectPath: project.dir,
          requirements: project.requirements
        });
        
        project.codingTaskId = codingResult.taskId;
      } else {
        throw new Error(`不支持的开发阶段: ${phase}`);
      }
      
      return {
        projectId,
        status: project.status,
        phase
      };
    } catch (error) {
      console.error('开始项目开发时出错:', error);
      
      // 更新项目状态为错误
      if (this.activeProjects[projectId]) {
        this.activeProjects[projectId].status = 'error';
        this.activeProjects[projectId].lastError = error.message;
      }
      
      throw new Error(`开始项目开发失败: ${error.message}`);
    }
  }

  // 暂停项目开发
  async pauseDevelopment(projectId) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      // 检查项目状态
      if (project.status !== 'developing') {
        throw new Error(`项目状态不允许暂停开发: ${project.status}`);
      }
      
      console.log(`项目管理器: 暂停项目开发 ${projectId}`);
      
      // 根据当前阶段暂停相应任务
      if (project.currentPhase === 'modeling') {
        await modelingService.pauseModelingTask();
      } else if (project.currentPhase === 'coding') {
        await ideService.pauseCodingTask();
      }
      
      // 更新项目状态
      project.status = 'paused';
      project.lastActivity = new Date();
      
      return {
        projectId,
        status: project.status
      };
    } catch (error) {
      console.error('暂停项目开发时出错:', error);
      throw new Error(`暂停项目开发失败: ${error.message}`);
    }
  }

  // 完成当前开发阶段
  async completePhase(projectId) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      // 检查项目状态
      if (project.status !== 'developing' && project.status !== 'paused') {
        throw new Error(`项目状态不允许完成阶段: ${project.status}`);
      }
      
      console.log(`项目管理器: 完成项目阶段 ${projectId}, 阶段: ${project.currentPhase}`);
      
      // 根据当前阶段完成相应任务
      let result;
      
      if (project.currentPhase === 'modeling') {
        result = await modelingService.completeModelingTask();
        
        // 处理建模结果
        if (result.success) {
          project.modelFiles = result.result.modelFiles;
        }
      } else if (project.currentPhase === 'coding') {
        result = await ideService.completeCodingTask();
      }
      
      // 更新项目状态
      project.status = 'phase_completed';
      project.lastActivity = new Date();
      project.completedPhases = project.completedPhases || [];
      project.completedPhases.push(project.currentPhase);
      
      // 检查是否所有阶段都已完成
      const allPhasesCompleted = 
        project.completedPhases.includes('modeling') && 
        project.completedPhases.includes('coding');
      
      if (allPhasesCompleted) {
        project.status = 'completed';
      }
      
      return {
        projectId,
        status: project.status,
        completedPhase: project.currentPhase,
        allPhasesCompleted
      };
    } catch (error) {
      console.error('完成项目阶段时出错:', error);
      throw new Error(`完成项目阶段失败: ${error.message}`);
    }
  }

  // 运行项目
  async runProject(projectId) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      console.log(`项目管理器: 运行项目 ${projectId}`);
      
      // 运行项目
      const result = await projectService.runProject();
      
      // 更新项目状态
      project.lastActivity = new Date();
      project.lastRunTime = new Date();
      
      return result;
    } catch (error) {
      console.error('运行项目时出错:', error);
      throw new Error(`运行项目失败: ${error.message}`);
    }
  }

  // 处理错误反馈
  async processFeedback(projectId, feedback) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      console.log(`项目管理器: 处理项目反馈 ${projectId}`);
      
      // 记录反馈
      project.feedback = project.feedback || [];
      project.feedback.push({
        id: uuidv4(),
        content: feedback.content,
        timestamp: new Date(),
        status: 'pending'
      });
      
      // 更新项目状态
      project.lastActivity = new Date();
      
      // 处理反馈
      const result = await aiIdeIntegration.processFeedback({
        sessionId: project.aiIdeSessionId,
        content: feedback.content
      });
      
      // 执行AI建议的操作
      if (result.actions && result.actions.length > 0) {
        for (const action of result.actions) {
          await this._executeAction(projectId, action);
        }
      }
      
      // 更新反馈状态
      const feedbackIndex = project.feedback.length - 1;
      project.feedback[feedbackIndex].status = 'processed';
      project.feedback[feedbackIndex].response = result.response;
      
      return {
        projectId,
        feedbackId: project.feedback[feedbackIndex].id,
        response: result.response,
        actions: result.actions
      };
    } catch (error) {
      console.error('处理项目反馈时出错:', error);
      throw new Error(`处理项目反馈失败: ${error.message}`);
    }
  }

  // 获取项目状态
  async getProjectStatus(projectId) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      const project = this.activeProjects[projectId];
      
      // 获取额外状态信息
      let phaseProgress = 0;
      let currentStep = '';
      
      if (project.status === 'developing') {
        if (project.currentPhase === 'modeling') {
          const modelingProgress = await modelingService.getModelingProgress();
          phaseProgress = modelingProgress.progress;
          currentStep = modelingProgress.currentStep;
        } else if (project.currentPhase === 'coding') {
          const codingProgress = await ideService.getCodingProgress();
          phaseProgress = codingProgress.progress;
          currentStep = codingProgress.currentStep;
        }
      }
      
      // 计算总体进度
      let overallProgress = 0;
      
      if (project.completedPhases && project.completedPhases.length > 0) {
        // 每个完成的阶段贡献50%的进度
        overallProgress = project.completedPhases.length * 50;
      }
      
      if (project.status === 'developing') {
        // 当前阶段的进度贡献剩余的百分比
        overallProgress += (phaseProgress / 100) * 50;
      }
      
      // 限制最大值为100
      overallProgress = Math.min(100, overallProgress);
      
      return {
        projectId,
        name: project.name,
        type: project.type,
        status: project.status,
        currentPhase: project.currentPhase,
        phaseProgress,
        currentStep,
        overallProgress,
        completedPhases: project.completedPhases || [],
        lastActivity: project.lastActivity,
        lastError: project.lastError
      };
    } catch (error) {
      console.error('获取项目状态时出错:', error);
      throw new Error(`获取项目状态失败: ${error.message}`);
    }
  }

  // 关闭项目
  async closeProject(projectId) {
    try {
      // 检查项目是否存在
      if (!this.activeProjects[projectId]) {
        throw new Error(`项目不存在: ${projectId}`);
      }
      
      console.log(`项目管理器: 关闭项目 ${projectId}`);
      
      // 保存项目状态
      await this._saveProject(projectId);
      
      // 清理自动保存定时器
      if (this.autoSaveTimers[projectId]) {
        clearInterval(this.autoSaveTimers[projectId]);
        delete this.autoSaveTimers[projectId];
      }
      
      // 结束AI-IDE会话
      if (this.activeProjects[projectId].aiIdeSessionId) {
        await aiIdeIntegration.endSession();
      }
      
      // 从活动项目中移除
      const project = { ...this.activeProjects[projectId] };
      delete this.activeProjects[projectId];
      
      return {
        projectId,
        status: 'closed'
      };
    } catch (error) {
      console.error('关闭项目时出错:', error);
      throw new Error(`关闭项目失败: ${error.message}`);
    }
  }

  // 初始化项目结构
  async _initializeProjectStructure(projectId, projectType, requirements) {
    try {
      const project = this.activeProjects[projectId];
      
      // 保存需求
      project.requirements = requirements;
      
      // 创建基本目录结构
      const dirs = [
        'src',
        'assets',
        'models',
        'docs',
        'build'
      ];
      
      for (const dir of dirs) {
        await fs.ensureDir(path.join(project.dir, dir));
      }
      
      // 创建README文件
      await fs.writeFile(
        path.join(project.dir, 'README.md'),
        `# ${project.name}\n\n${requirements.description || '游戏项目'}\n\n## 需求\n\n${JSON.stringify(requirements, null, 2)}`
      );
      
      console.log(`项目管理器: 初始化项目结构 ${projectId}`);
      
      return { success: true };
    } catch (error) {
      console.error('初始化项目结构时出错:', error);
      throw error;
    }
  }

  // 创建项目文件
  async _createProjectFiles(projectId, structure) {
    try {
      const project = this.activeProjects[projectId];
      
      // 创建目录
      for (const dir of structure.directories) {
        await fs.ensureDir(path.join(project.dir, dir.path));
      }
      
      // 创建文件
      for (const file of structure.files) {
        // 生成文件内容
        const content = await this._generateFileContent(projectId, file.name, file.description);
        
        // 确定文件路径
        let filePath;
        if (file.name.endsWith('.html')) {
          filePath = path.join(project.dir, 'src', file.name);
        } else if (file.name.endsWith('.js')) {
          filePath = path.join(project.dir, 'src', 'js', file.name);
        } else if (file.name.endsWith('.css')) {
          filePath = path.join(project.dir, 'src', 'css', file.name);
        } else if (file.name.endsWith('.md')) {
          filePath = path.join(project.dir, 'docs', file.name);
        } else {
          filePath = path.join(project.dir, 'src', file.name);
        }
        
        // 确保目录存在
        await fs.ensureDir(path.dirname(filePath));
        
        // 写入文件
        await fs.writeFile(filePath, content);
      }
      
      console.log(`项目管理器: 创建项目文件 ${projectId}, 文件数: ${structure.files.length}`);
      
      return { success: true };
    } catch (error) {
      console.error('创建项目文件时出错:', error);
      throw error;
    }
  }

  // 生成文件内容
  async _generateFileContent(projectId, fileName, description) {
    try {
      const project = this.activeProjects[projectId];
      
      // 根据文件类型生成内容
      const fileExt = path.extname(fileName).toLowerCase();
      
      // 使用AI生成代码
      let language;
      switch (fileExt) {
        case '.js':
          language = 'javascript';
          break;
        case '.html':
          language = 'html';
          break;
        case '.css':
          language = 'css';
          break;
        case '.md':
          language = 'markdown';
          break;
        default:
          language = 'text';
      }
      
      // 只为代码文件生成内容
      if (['.js',<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>