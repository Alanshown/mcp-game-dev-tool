const fs = require('fs-extra');
const path = require('path');
const { spawn, exec } = require('child_process');
const { v4: uuidv4 } = require('uuid');

// 配置文件路径
const PROJECTS_DIR = path.join(__dirname, '../data/projects');
const CONFIG_PATH = path.join(__dirname, '../config/project-config.json');

// 确保目录存在
fs.ensureDirSync(PROJECTS_DIR);
fs.ensureDirSync(path.dirname(CONFIG_PATH));

// 默认配置
const DEFAULT_CONFIG = {
  defaultProjectType: '2d',
  projectTemplates: {
    '2d': 'html5-canvas',
    '3d': 'three-js'
  }
};

// 初始化配置
if (!fs.existsSync(CONFIG_PATH)) {
  fs.writeJsonSync(CONFIG_PATH, DEFAULT_CONFIG, { spaces: 2 });
}

class ProjectService {
  constructor() {
    this.config = fs.existsSync(CONFIG_PATH) 
      ? fs.readJsonSync(CONFIG_PATH) 
      : DEFAULT_CONFIG;
    
    // 当前项目
    this.currentProject = null;
  }

  // 创建新项目
  async createProject(projectData) {
    try {
      const { name, type, description } = projectData;
      
      if (!name) {
        throw new Error('项目名称不能为空');
      }
      
      // 创建项目ID
      const projectId = uuidv4();
      
      // 创建项目目录
      const projectDir = path.join(PROJECTS_DIR, projectId);
      await fs.ensureDir(projectDir);
      
      // 创建项目配置文件
      const projectConfig = {
        id: projectId,
        name,
        type: type || this.config.defaultProjectType,
        description: description || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'created'
      };
      
      // 保存项目配置
      await fs.writeJson(path.join(projectDir, 'project.json'), projectConfig, { spaces: 2 });
      
      // 创建项目结构
      await this._createProjectStructure(projectDir, projectConfig.type);
      
      console.log(`创建项目: ${name}, ID: ${projectId}`);
      
      // 设置为当前项目
      this.currentProject = {
        ...projectConfig,
        dir: projectDir
      };
      
      return this.currentProject;
    } catch (error) {
      console.error('创建项目时出错:', error);
      throw new Error(`创建项目失败: ${error.message}`);
    }
  }

  // 获取项目列表
  async getProjects() {
    try {
      // 确保项目目录存在
      await fs.ensureDir(PROJECTS_DIR);
      
      // 读取所有项目目录
      const projectDirs = await fs.readdir(PROJECTS_DIR);
      
      // 收集项目信息
      const projects = [];
      
      for (const dir of projectDirs) {
        const projectPath = path.join(PROJECTS_DIR, dir);
        const configPath = path.join(projectPath, 'project.json');
        
        // 检查是否是目录且包含项目配置文件
        if ((await fs.stat(projectPath)).isDirectory() && await fs.pathExists(configPath)) {
          try {
            const projectConfig = await fs.readJson(configPath);
            projects.push({
              ...projectConfig,
              dir: projectPath
            });
          } catch (err) {
            console.error(`读取项目配置失败: ${configPath}`, err);
          }
        }
      }
      
      return projects;
    } catch (error) {
      console.error('获取项目列表时出错:', error);
      throw new Error(`获取项目列表失败: ${error.message}`);
    }
  }

  // 获取项目详情
  async getProjectById(id) {
    try {
      const projectPath = path.join(PROJECTS_DIR, id);
      const configPath = path.join(projectPath, 'project.json');
      
      // 检查项目是否存在
      if (!await fs.pathExists(configPath)) {
        throw new Error(`项目不存在: ${id}`);
      }
      
      // 读取项目配置
      const projectConfig = await fs.readJson(configPath);
      
      return {
        ...projectConfig,
        dir: projectPath
      };
    } catch (error) {
      console.error('获取项目详情时出错:', error);
      throw new Error(`获取项目详情失败: ${error.message}`);
    }
  }

  // 保存项目配置
  async saveProjectConfig(config) {
    try {
      if (!this.currentProject) {
        // 如果没有当前项目，创建一个新项目
        return await this.createProject(config);
      }
      
      // 更新项目配置
      const updatedConfig = {
        ...this.currentProject,
        ...config,
        updatedAt: new Date().toISOString()
      };
      
      // 保存到文件
      const configPath = path.join(this.currentProject.dir, 'project.json');
      await fs.writeJson(configPath, updatedConfig, { spaces: 2 });
      
      console.log(`更新项目配置: ${this.currentProject.id}`);
      
      // 更新当前项目
      this.currentProject = {
        ...updatedConfig,
        dir: this.currentProject.dir
      };
      
      return this.currentProject;
    } catch (error) {
      console.error('保存项目配置时出错:', error);
      throw new Error(`保存项目配置失败: ${error.message}`);
    }
  }

  // 保存项目需求
  async saveRequirements(requirements) {
    try {
      if (!this.currentProject) {
        throw new Error('没有当前项目');
      }
      
      // 保存需求到文件
      const requirementsPath = path.join(this.currentProject.dir, 'requirements.json');
      await fs.writeJson(requirementsPath, requirements, { spaces: 2 });
      
      console.log(`保存项目需求: ${this.currentProject.id}`);
      
      // 更新项目状态
      await this.saveProjectConfig({
        status: 'requirements_defined'
      });
      
      return { success: true, message: '项目需求已保存' };
    } catch (error) {
      console.error('保存项目需求时出错:', error);
      throw new Error(`保存项目需求失败: ${error.message}`);
    }
  }

  // 运行项目
  async runProject() {
    try {
      if (!this.currentProject) {
        throw new Error('没有当前项目');
      }
      
      // 检查项目状态
      if (this.currentProject.status !== 'completed') {
        throw new Error('项目尚未完成，无法运行');
      }
      
      console.log(`运行项目: ${this.currentProject.id}`);
      
      // 根据项目类型选择运行方式
      if (this.currentProject.type === '2d') {
        // 运行2D游戏
        return this._run2DGame();
      } else if (this.currentProject.type === '3d') {
        // 运行3D游戏
        return this._run3DGame();
      } else {
        throw new Error(`不支持的项目类型: ${this.currentProject.type}`);
      }
    } catch (error) {
      console.error('运行项目时出错:', error);
      throw new Error(`运行项目失败: ${error.message}`);
    }
  }

  // 获取项目状态
  async getProjectStatus(id) {
    try {
      // 获取项目详情
      const project = await this.getProjectById(id);
      
      // 收集项目文件信息
      const fileStats = await this._collectProjectFileStats(project.dir);
      
      return {
        id: project.id,
        name: project.name,
        type: project.type,
        status: project.status,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt,
        fileStats
      };
    } catch (error) {
      console.error('获取项目状态时出错:', error);
      throw new Error(`获取项目状态失败: ${error.message}`);
    }
  }

  // 创建项目结构
  async _createProjectStructure(projectDir, type) {
    try {
      // 创建基本目录结构
      const dirs = [
        'src',
        'assets',
        'docs',
        'models',
        'build'
      ];
      
      for (const dir of dirs) {
        await fs.ensureDir(path.join(projectDir, dir));
      }
      
      // 根据项目类型创建特定结构
      if (type === '2d') {
        // 2D游戏项目结构
        await fs.ensureDir(path.join(projectDir, 'src/js'));
        await fs.ensureDir(path.join(projectDir, 'src/css'));
        await fs.ensureDir(path.join(projectDir, 'assets/images'));
        await fs.ensureDir(path.join(projectDir, 'assets/audio'));
        
        // 创建基本HTML文件
        await fs.writeFile(
          path.join(projectDir, 'src/index.html'),
          `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>2D Game</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <canvas id="gameCanvas"></canvas>
  <script src="js/main.js"></script>
</body>
</html>`
        );
        
        // 创建基本CSS文件
        await fs.writeFile(
          path.join(projectDir, 'src/css/style.css'),
          `body {
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #000;
}

#gameCanvas {
  display: block;
  width: 100vw;
  height: 100vh;
}`
        );
        
        // 创建基本JS文件
        await fs.writeFile(
          path.join(projectDir, 'src/js/main.js'),
          `// 游戏主入口
window.addEventListener('load', function() {
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  
  // 设置画布尺寸
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  
  // 游戏循环
  function gameLoop() {
    // 清空画布
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // 绘制游戏内容
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(100, 100, 50, 50);
    
    // 继续循环
    requestAnimationFrame(gameLoop);
  }
  
  // 启动游戏循环
  gameLoop();
});`
        );
      } else if (type === '3d') {
        // 3D游戏项目结构
        await fs.ensureDir(path.join(projectDir, 'src/js'));
        await fs.ensureDir(path.join(projectDir, 'src/css'));
        await fs.ensureDir(path.join(projectDir, 'assets/textures'));
        await fs.ensureDir(path.join(projectDir, 'assets/models'));
        await fs.ensureDir(path.join(projectDir, 'assets/audio'));
        
        // 创建基本HTML文件
        await fs.writeFile(
          path.join(projectDir, 'src/index.html'),
          `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>3D Game</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/three@0.132.2/build/three.min.js"></script>
</head>
<body>
  <div id="gameContainer"></div>
  <script src="js/main.js"></script>
</body>
</html>`
        );
        
        // 创建基本CSS文件
        await fs.writeFile(
          path.join(projectDir, 'src/css/style.css'),
          `body {
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #000;
}

#gameContainer {
  position: absolute;
  width: 100%;
  height: 100%;
}`
        );
        
        // 创建基本JS文件
        await fs.writeFile(
          path.join(projectDir, 'src/js/main.js'),
          `// 游戏主入口
window.addEventListener('load', function() {
  // 创建场景
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x000000);
  
  // 创建相机
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.z = 5;
  
  // 创建渲染器
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.getElementById('gameContainer').appendChild(renderer.domElement);
  
  // 添加立方体
  const geometry = new THREE.BoxGeometry();
  const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
  const cube = new THREE.Mesh(geometry, material);
  scene.add(cube);
  
  // 游戏循环
  function animate() {
    requestAnimationFrame(animate);
    
    // 旋转立方体
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    
    // 渲染场景
    renderer.render(scene, camera);
  }
  
  // 启动游戏循环
  animate();
  
  // 窗口大小调整
  window.addEventListener('resize', function() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
});`
        );
      }
      
      console.log(`创建项目结构: ${projectDir}, 类型: ${type}`);
      
      return { success: true };
    } catch (error) {
      console.error('创建项目结构时出错:', error);
      throw error;
    }
  }

  // 运行2D游戏
  async _run2DGame() {
    try {
      // 在实际环境中，这里应该启动一个本地服务器来运行游戏
      // 在沙盒环境中，我们模拟这个过程
      
      console.log(`运行2D游戏: ${this.currentProject.id}`);
      
      return {
        success: true,
        message: '2D游戏已启动',
        url: `http://localhost:8080/projects/${this.currentProject.id}/`
      };
    } catch (error) {
      console.error('运行2D游戏时出错:', error);
      throw error;
    }
  }

  // 运行3D游戏
  async _run3DGame() {
    try {
      // 在实际环境中，这里应该启动一个本地服务器来运行游戏
      // 在沙盒环境中，我们模拟这个过程
      
      console.log(`运行3D游戏: ${this.currentProject.id}`);
      
      return {
        success: true,
        message: '3D游戏已启动',
        url: `http://localhost:8080/projects/${this.currentProject.id}/`
      };
    } catch (error) {
      console.error('运行3D游戏时出错:', error);
      throw error;
    }
  }

  // 收集项目文件统计信息
  async _collectProjectFileStats(projectDir) {
    try {
      const stats = {
        totalFiles: 0,
        codeFiles: 0,
        assetFiles: 0,
        modelFiles: 0,
        totalSize: 0
      };
      
      // 递归遍历目录
      async function traverseDir(dir) {
        const files = await fs.readdir(dir);
        
        for (const file of files) {
          const filePath = path.join(dir, file);
          const stat = await fs.stat(filePath);
          
          if (stat.isDirectory()) {
            await traverseDir(filePath);
          } else {
            stats.totalFiles++;
            stats.totalSize += stat.size;
            
            const ext = path.extname(file).toLowerCase();
            
            if (['.js', '.html', '.css', '.json'].includes(ext)) {
              stats.codeFiles++;
            } else if (['.png', '.jpg', '.jpeg', '.gif', '.svg', '.mp3', '.wav', '.ogg'].includes(ext)) {
              stats.assetFiles++;
            } else if (['.obj', '.fbx', '.blend', '.3ds', '.dae'].includes(ext)) {
              stats.modelFiles++;
            }
          }
        }
      }
      
      await traverseDir(projectDir);
      
      return stats;
    } catch (error) {
      console.error('收集项目文件统计信息时出错:', error);
      return {
        totalFiles: 0,
        codeFiles: 0,
        assetFiles: 0,
        modelFiles: 0,
        totalSize: 0
      };
    }
  }
}

module.exports = new ProjectService();
