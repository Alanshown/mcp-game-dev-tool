const fs = require('fs-extra');
const path = require('path');
const { spawn, exec } = require('child_process');
const { v4: uuidv4 } = require('uuid');

// 配置文件路径
const CONFIG_PATH = path.join(__dirname, '../config/modeling-config.json');

// 确保配置目录存在
fs.ensureDirSync(path.dirname(CONFIG_PATH));

// 默认配置
const DEFAULT_CONFIG = {
  defaultSoftware: 'blender',
  softwarePaths: {
    blender: '/usr/bin/blender',
    maya: '/usr/bin/maya',
    '3dsmax': '/usr/bin/3dsmax'
  }
};

// 初始化配置
if (!fs.existsSync(CONFIG_PATH)) {
  fs.writeJsonSync(CONFIG_PATH, DEFAULT_CONFIG, { spaces: 2 });
}

class ModelingService {
  constructor() {
    this.config = fs.existsSync(CONFIG_PATH) 
      ? fs.readJsonSync(CONFIG_PATH) 
      : DEFAULT_CONFIG;
    
    // 当前任务状态
    this.currentTask = null;
    this.taskProgress = 0;
    this.modelingProcess = null;
  }

  // 获取可用的建模软件列表
  async getAvailableModelingSoftware() {
    return [
      { id: 'blender', name: 'Blender', path: this.config.softwarePaths.blender },
      { id: 'maya', name: 'Maya', path: this.config.softwarePaths.maya },
      { id: '3dsmax', name: '3ds Max', path: this.config.softwarePaths['3dsmax'] }
    ];
  }

  // 启动指定的建模软件
  async launchModelingSoftware(softwareName, projectPath) {
    try {
      const softwarePath = this.config.softwarePaths[softwareName] || this.config.softwarePaths[this.config.defaultSoftware];
      
      if (!softwarePath) {
        throw new Error(`未找到建模软件: ${softwareName}`);
      }
      
      // 确保项目路径存在
      await fs.ensureDir(projectPath);
      
      console.log(`启动建模软件: ${softwarePath}, 项目路径: ${projectPath}`);
      
      // 在实际环境中，这里应该使用child_process启动建模软件
      // 在沙盒环境中，我们模拟这个过程
      this.modelingProcess = {
        id: uuidv4(),
        name: softwareName,
        projectPath,
        status: 'running'
      };
      
      return {
        success: true,
        message: `已启动建模软件: ${softwareName}`,
        processId: this.modelingProcess.id
      };
    } catch (error) {
      console.error('启动建模软件时出错:', error);
      throw new Error(`启动建模软件失败: ${error.message}`);
    }
  }

  // 开始建模任务
  async startModelingTask(taskData) {
    try {
      const { softwareName, projectPath, requirements } = taskData;
      
      // 启动建模软件
      await this.launchModelingSoftware(softwareName, projectPath);
      
      // 创建任务
      this.currentTask = {
        id: uuidv4(),
        type: 'modeling',
        softwareName,
        projectPath,
        requirements,
        status: 'running',
        startTime: new Date(),
        progress: 0
      };
      
      console.log(`开始建模任务: ${this.currentTask.id}`);
      
      // 模拟任务进度更新
      this._startProgressSimulation();
      
      return {
        success: true,
        taskId: this.currentTask.id,
        message: '建模任务已开始'
      };
    } catch (error) {
      console.error('开始建模任务时出错:', error);
      throw new Error(`开始建模任务失败: ${error.message}`);
    }
  }

  // 暂停建模任务
  async pauseModelingTask() {
    try {
      if (!this.currentTask) {
        throw new Error('没有正在进行的建模任务');
      }
      
      this.currentTask.status = 'paused';
      console.log(`暂停建模任务: ${this.currentTask.id}`);
      
      // 停止进度模拟
      this._stopProgressSimulation();
      
      return {
        success: true,
        message: '建模任务已暂停'
      };
    } catch (error) {
      console.error('暂停建模任务时出错:', error);
      throw new Error(`暂停建模任务失败: ${error.message}`);
    }
  }

  // 完成建模任务
  async completeModelingTask() {
    try {
      if (!this.currentTask) {
        throw new Error('没有正在进行的建模任务');
      }
      
      this.currentTask.status = 'completed';
      this.currentTask.progress = 100;
      this.currentTask.endTime = new Date();
      
      console.log(`完成建模任务: ${this.currentTask.id}`);
      
      // 停止进度模拟
      this._stopProgressSimulation();
      
      // 收集任务结果
      const result = {
        taskId: this.currentTask.id,
        softwareName: this.currentTask.softwareName,
        projectPath: this.currentTask.projectPath,
        duration: (this.currentTask.endTime - this.currentTask.startTime) / 1000, // 秒
        status: 'completed',
        modelFiles: await this._collectModelFiles(this.currentTask.projectPath)
      };
      
      // 清理当前任务
      const completedTask = { ...this.currentTask };
      this.currentTask = null;
      
      return {
        success: true,
        message: '建模任务已完成',
        result
      };
    } catch (error) {
      console.error('完成建模任务时出错:', error);
      throw new Error(`完成建模任务失败: ${error.message}`);
    }
  }

  // 获取建模进度
  async getModelingProgress() {
    try {
      if (!this.currentTask) {
        return {
          status: 'no_task',
          progress: 0,
          message: '没有正在进行的建模任务'
        };
      }
      
      return {
        taskId: this.currentTask.id,
        status: this.currentTask.status,
        progress: this.currentTask.progress,
        startTime: this.currentTask.startTime,
        currentStep: this._getCurrentStep(),
        completed: this.currentTask.progress >= 100
      };
    } catch (error) {
      console.error('获取建模进度时出错:', error);
      throw new Error(`获取建模进度失败: ${error.message}`);
    }
  }

  // 导出模型文件
  async exportModel(format, destination) {
    try {
      if (!this.currentTask) {
        throw new Error('没有正在进行的建模任务');
      }
      
      // 确保目标目录存在
      await fs.ensureDir(destination);
      
      // 模拟导出过程
      console.log(`导出模型: 格式=${format}, 目标=${destination}`);
      
      // 创建一个示例模型文件
      const modelFileName = `model_${Date.now()}.${format}`;
      const modelFilePath = path.join(destination, modelFileName);
      
      // 写入一些示例数据
      await fs.writeFile(modelFilePath, `This is a sample ${format} model file.`);
      
      return {
        success: true,
        message: `模型已导出为 ${format} 格式`,
        filePath: modelFilePath
      };
    } catch (error) {
      console.error('导出模型时出错:', error);
      throw new Error(`导出模型失败: ${error.message}`);
    }
  }

  // 导入模型文件到项目
  async importModelToProject(modelPath, projectPath) {
    try {
      // 确保项目目录存在
      await fs.ensureDir(projectPath);
      
      // 确保模型文件存在
      if (!await fs.pathExists(modelPath)) {
        throw new Error(`模型文件不存在: ${modelPath}`);
      }
      
      // 复制模型文件到项目目录
      const modelFileName = path.basename(modelPath);
      const destPath = path.join(projectPath, 'models', modelFileName);
      
      // 确保目标目录存在
      await fs.ensureDir(path.dirname(destPath));
      
      // 复制文件
      await fs.copy(modelPath, destPath);
      
      console.log(`导入模型: ${modelPath} -> ${destPath}`);
      
      return {
        success: true,
        message: `模型已导入到项目`,
        originalPath: modelPath,
        projectPath: destPath
      };
    } catch (error) {
      console.error('导入模型时出错:', error);
      throw new Error(`导入模型失败: ${error.message}`);
    }
  }

  // 模拟任务进度更新
  _startProgressSimulation() {
    // 清除可能存在的旧定时器
    this._stopProgressSimulation();
    
    // 创建新的进度更新定时器
    this.progressInterval = setInterval(() => {
      if (this.currentTask && this.currentTask.status === 'running') {
        // 增加进度，最大100
        this.currentTask.progress = Math.min(100, this.currentTask.progress + 5);
        
        console.log(`建模任务进度更新: ${this.currentTask.progress}%`);
        
        // 如果达到100%，自动完成任务
        if (this.currentTask.progress >= 100) {
          this.completeModelingTask().catch(console.error);
        }
      }
    }, 5000); // 每5秒更新一次
  }

  // 停止进度模拟
  _stopProgressSimulation() {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  }

  // 获取当前步骤描述
  _getCurrentStep() {
    if (!this.currentTask) return '';
    
    const progress = this.currentTask.progress;
    
    if (progress < 20) {
      return '创建基本模型形状';
    } else if (progress < 40) {
      return '添加细节和特征';
    } else if (progress < 60) {
      return '设置材质和纹理';
    } else if (progress < 80) {
      return '创建动画骨架';
    } else {
      return '优化和导出';
    }
  }

  // 收集模型文件
  async _collectModelFiles(projectPath) {
    try {
      const modelsDir = path.join(projectPath, 'models');
      
      // 确保目录存在
      if (!await fs.pathExists(modelsDir)) {
        return [];
      }
      
      // 读取目录内容
      const files = await fs.readdir(modelsDir);
      
      // 过滤出模型文件
      const modelExtensions = ['.obj', '.fbx', '.blend', '.3ds', '.dae'];
      const modelFiles = files.filter(file => {
        const ext = path.extname(file).toLowerCase();
        return modelExtensions.includes(ext);
      });
      
      // 返回完整路径
      return modelFiles.map(file => path.join(modelsDir, file));
    } catch (error) {
      console.error('收集模型文件时出错:', error);
      return [];
    }
  }
}

module.exports = new ModelingService();
