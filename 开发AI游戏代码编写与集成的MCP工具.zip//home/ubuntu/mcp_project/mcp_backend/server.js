const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
const fs = require('fs-extra');
const { spawn, exec } = require('child_process');

// 导入服务模块
const aiService = require('./services/aiService');
const ideService = require('./services/ideService');
const modelingService = require('./services/modelingService');
const projectService = require('./services/projectService');

// 创建Express应用
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));

// API路由
app.use('/api/project', require('./routes/projectRoutes'));
app.use('/api/ai', require('./routes/aiRoutes'));
app.use('/api/ide', require('./routes/ideRoutes'));
app.use('/api/modeling', require('./routes/modelingRoutes'));
app.use('/api/ai-ide', require('./routes/aiIdeRoutes'));
app.use('/api/project-manager', require('./routes/projectManagerRoutes'));

// WebSocket连接处理
io.on('connection', (socket) => {
  console.log('客户端已连接:', socket.id);
  
  // 项目配置事件
  socket.on('project:config', (config) => {
    console.log('收到项目配置:', config);
    projectService.saveProjectConfig(config)
      .then(() => {
        socket.emit('project:config:success', { message: '项目配置已保存' });
      })
      .catch((error) => {
        socket.emit('project:config:error', { error: error.message });
      });
  });
  
  // 需求提交事件
  socket.on('requirements:submit', (requirements) => {
    console.log('收到项目需求:', requirements);
    projectService.saveRequirements(requirements)
      .then(() => {
        socket.emit('requirements:submit:success', { message: '项目需求已保存' });
        // 触发AI处理
        return aiService.processRequirements(requirements);
      })
      .then((aiResponse) => {
        socket.emit('ai:response', aiResponse);
      })
      .catch((error) => {
        socket.emit('requirements:submit:error', { error: error.message });
      });
  });
  
  // API配置事件
  socket.on('api:config', (config) => {
    console.log('收到API配置:', config);
    aiService.saveApiConfig(config)
      .then(() => {
        socket.emit('api:config:success', { message: 'API配置已保存' });
      })
      .catch((error) => {
        socket.emit('api:config:error', { error: error.message });
      });
  });
  
  // 工作流控制事件
  socket.on('workflow:start', (data) => {
    console.log('开始工作流:', data);
    const { type } = data; // 'modeling' 或 'coding'
    
    if (type === 'modeling') {
      modelingService.startModelingTask(data)
        .then((result) => {
          socket.emit('modeling:started', result);
          // 发送实时进度更新
          const progressInterval = setInterval(() => {
            modelingService.getModelingProgress()
              .then((progress) => {
                socket.emit('modeling:progress', progress);
                if (progress.completed) {
                  clearInterval(progressInterval);
                }
              });
          }, 2000);
        })
        .catch((error) => {
          socket.emit('workflow:error', { error: error.message });
        });
    } else if (type === 'coding') {
      ideService.startCodingTask(data)
        .then((result) => {
          socket.emit('coding:started', result);
          // 发送实时进度更新
          const progressInterval = setInterval(() => {
            ideService.getCodingProgress()
              .then((progress) => {
                socket.emit('coding:progress', progress);
                if (progress.completed) {
                  clearInterval(progressInterval);
                }
              });
          }, 2000);
        })
        .catch((error) => {
          socket.emit('workflow:error', { error: error.message });
        });
    }
  });
  
  // 工作流暂停事件
  socket.on('workflow:pause', (data) => {
    console.log('暂停工作流:', data);
    const { type } = data;
    
    if (type === 'modeling') {
      modelingService.pauseModelingTask()
        .then(() => {
          socket.emit('modeling:paused', { message: '建模任务已暂停' });
        })
        .catch((error) => {
          socket.emit('workflow:error', { error: error.message });
        });
    } else if (type === 'coding') {
      ideService.pauseCodingTask()
        .then(() => {
          socket.emit('coding:paused', { message: '编码任务已暂停' });
        })
        .catch((error) => {
          socket.emit('workflow:error', { error: error.message });
        });
    }
  });
  
  // 工作流完成事件
  socket.on('workflow:complete', (data) => {
    console.log('完成工作流:', data);
    const { type } = data;
    
    if (type === 'modeling') {
      modelingService.completeModelingTask()
        .then((result) => {
          socket.emit('modeling:completed', result);
        })
        .catch((error) => {
          socket.emit('workflow:error', { error: error.message });
        });
    } else if (type === 'coding') {
      ideService.completeCodingTask()
        .then((result) => {
          socket.emit('coding:completed', result);
        })
        .catch((error) => {
          socket.emit('workflow:error', { error: error.message });
        });
    }
  });
  
  // 运行项目事件
  socket.on('project:run', () => {
    console.log('运行项目');
    projectService.runProject()
      .then((result) => {
        socket.emit('project:running', result);
      })
      .catch((error) => {
        socket.emit('project:run:error', { error: error.message });
      });
  });
  
  // 反馈提交事件
  socket.on('feedback:submit', (feedback) => {
    console.log('收到反馈:', feedback);
    aiService.processFeedback(feedback)
      .then((result) => {
        socket.emit('feedback:processed', result);
      })
      .catch((error) => {
        socket.emit('feedback:error', { error: error.message });
      });
  });
  
  // 断开连接事件
  socket.on('disconnect', () => {
    console.log('客户端已断开连接:', socket.id);
  });
});

// 启动服务器
const PORT = process.env.PORT || 7090;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`MCP服务器运行在 http://localhost:${PORT}`);
});

// 处理未捕获的异常
process.on('uncaughtException', (error) => {
  console.error('未捕获的异常:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('未处理的Promise拒绝:', reason);
});

module.exports = { app, server, io };
