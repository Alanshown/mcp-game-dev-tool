import { ProjectConfigPanel } from "@/components/project/ProjectConfigPanel";
import { RequirementInputPanel } from "@/components/project/RequirementInputPanel";
import { ApiConfigPanel } from "@/components/api/ApiConfigPanel";
import { WorkflowControlPanel } from "@/components/workflow/WorkflowControlPanel";
import { FeedbackPanel } from "@/components/feedback/FeedbackPanel";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Home() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-4xl font-bold text-center mb-10">MCP - AI游戏开发助手</h1>
      
      <Tabs defaultValue="project" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="project">项目配置</TabsTrigger>
          <TabsTrigger value="requirements">需求输入</TabsTrigger>
          <TabsTrigger value="api">API配置</TabsTrigger>
          <TabsTrigger value="workflow">工作流控制</TabsTrigger>
        </TabsList>
        
        <TabsContent value="project">
          <ProjectConfigPanel />
        </TabsContent>
        
        <TabsContent value="requirements">
          <RequirementInputPanel />
        </TabsContent>
        
        <TabsContent value="api">
          <ApiConfigPanel />
        </TabsContent>
        
        <TabsContent value="workflow">
          <WorkflowControlPanel />
        </TabsContent>
      </Tabs>
      
      <div className="mt-10">
        <FeedbackPanel />
      </div>
    </div>
  );
}
