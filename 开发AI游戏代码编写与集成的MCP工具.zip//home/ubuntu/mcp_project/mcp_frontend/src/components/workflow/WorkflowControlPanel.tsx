import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";

export function WorkflowControlPanel() {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>工作流控制</CardTitle>
        <CardDescription>
          控制建模和编码分区的切换，监控项目执行进度
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="modeling" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="modeling">建模分区</TabsTrigger>
            <TabsTrigger value="coding">编码分区</TabsTrigger>
          </TabsList>
          
          <TabsContent value="modeling" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>建模任务状态</Label>
              <div className="flex items-center justify-between">
                <span>进行中</span>
                <Progress value={45} className="w-2/3" />
                <span>45%</span>
              </div>
            </div>
            
            <div className="p-4 border rounded-md bg-muted">
              <h4 className="font-medium mb-2">当前任务</h4>
              <p>在Blender中创建游戏角色模型</p>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline">暂停任务</Button>
              <Button>完成建模分区</Button>
            </div>
          </TabsContent>
          
          <TabsContent value="coding" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>编码任务状态</Label>
              <div className="flex items-center justify-between">
                <span>等待中</span>
                <Progress value={0} className="w-2/3" />
                <span>0%</span>
              </div>
            </div>
            
            <div className="p-4 border rounded-md bg-muted">
              <h4 className="font-medium mb-2">等待任务</h4>
              <p>等待建模分区完成后开始编码</p>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" disabled>暂停任务</Button>
              <Button disabled>完成编码分区</Button>
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="space-y-2 pt-4 border-t">
          <Label>整体项目进度</Label>
          <div className="flex items-center justify-between">
            <span>进行中</span>
            <Progress value={25} className="w-2/3" />
            <span>25%</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline">取消项目</Button>
        <Button>运行项目</Button>
      </CardFooter>
    </Card>
  );
}
