import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export function ApiConfigPanel() {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>API配置</CardTitle>
        <CardDescription>
          配置AI模型和相关参数，用于游戏代码生成和项目管理
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="model-select">AI模型</Label>
          <Select>
            <SelectTrigger id="model-select">
              <SelectValue placeholder="选择AI模型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gpt-4">GPT-4</SelectItem>
              <SelectItem value="claude-3">Claude 3</SelectItem>
              <SelectItem value="gemini-pro">Gemini Pro</SelectItem>
              <SelectItem value="llama-3">Llama 3</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="api-key">API密钥</Label>
          <Input
            id="api-key"
            type="password"
            placeholder="输入API密钥"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="temperature">温度 (创造性)</Label>
          <div className="flex items-center space-x-2">
            <Input
              id="temperature"
              type="range"
              min="0"
              max="1"
              step="0.1"
              defaultValue="0.7"
              className="w-full"
            />
            <span className="w-12 text-center">0.7</span>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="max-tokens">最大令牌数</Label>
          <Input
            id="max-tokens"
            type="number"
            defaultValue="4096"
            min="1"
            max="8192"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Switch id="advanced-mode" />
          <Label htmlFor="advanced-mode">启用高级模式</Label>
        </div>

        <div className="flex items-center space-x-2">
          <Switch id="save-history" defaultChecked />
          <Label htmlFor="save-history">保存会话历史</Label>
        </div>
      </CardContent>
      <CardFooter>
        <Button>保存API配置</Button>
      </CardFooter>
    </Card>
  );
}
