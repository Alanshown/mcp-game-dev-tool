import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export function ProjectConfigPanel() {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>项目配置</CardTitle>
        <CardDescription>
          配置游戏项目类型、选择IDE和建模软件
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="project-type">项目类型</Label>
          <RadioGroup defaultValue="2d" className="flex space-x-4">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="2d" id="2d" />
              <Label htmlFor="2d">2D游戏</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="3d" id="3d" />
              <Label htmlFor="3d">3D游戏</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label htmlFor="ide-select">代码编辑器</Label>
          <Select>
            <SelectTrigger id="ide-select">
              <SelectValue placeholder="选择代码编辑器" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cursor">Cursor</SelectItem>
              <SelectItem value="trea">Trea</SelectItem>
              <SelectItem value="windsurf">Windsurf</SelectItem>
              <SelectItem value="vscode">Visual Studio Code</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="modeling-select">建模软件</Label>
          <Select>
            <SelectTrigger id="modeling-select">
              <SelectValue placeholder="选择建模软件" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="blender">Blender</SelectItem>
              <SelectItem value="maya">Maya</SelectItem>
              <SelectItem value="3dsmax">3ds Max</SelectItem>
              <SelectItem value="none">不需要建模</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="workflow-select">工作流程</Label>
          <RadioGroup defaultValue="code-first" className="flex space-x-4">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="code-first" id="code-first" />
              <Label htmlFor="code-first">先编码后建模</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="model-first" id="model-first" />
              <Label htmlFor="model-first">先建模后编码</Label>
            </div>
          </RadioGroup>
        </div>
      </CardContent>
      <CardFooter>
        <Button>保存配置</Button>
      </CardFooter>
    </Card>
  );
}
