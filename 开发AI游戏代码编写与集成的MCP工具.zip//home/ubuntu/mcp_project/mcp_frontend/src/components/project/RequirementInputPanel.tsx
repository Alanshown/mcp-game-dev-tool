import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export function RequirementInputPanel() {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>需求输入</CardTitle>
        <CardDescription>
          详细描述您的游戏项目需求，AI将根据您的描述生成游戏代码
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="game-name">游戏名称</Label>
          <input
            id="game-name"
            className="w-full p-2 border rounded-md"
            placeholder="输入游戏名称"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="game-description">游戏描述</Label>
          <Textarea
            id="game-description"
            placeholder="描述游戏的基本玩法、目标和特点"
            className="min-h-[100px]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="game-features">游戏功能</Label>
          <Textarea
            id="game-features"
            placeholder="列出游戏需要实现的主要功能和特性"
            className="min-h-[100px]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="game-assets">游戏资源需求</Label>
          <Textarea
            id="game-assets"
            placeholder="描述游戏需要的图形、音效、模型等资源"
            className="min-h-[100px]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="additional-requirements">其他要求</Label>
          <Textarea
            id="additional-requirements"
            placeholder="其他特殊要求或参考资料"
            className="min-h-[100px]"
          />
        </div>
      </CardContent>
      <CardFooter>
        <Button>提交需求</Button>
      </CardFooter>
    </Card>
  );
}
