import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

export function FeedbackPanel() {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>项目反馈</CardTitle>
        <CardDescription>
          查看项目执行状态和错误反馈，提交问题修复请求
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">执行日志</h3>
            <Badge variant="outline">实时更新</Badge>
          </div>
          <ScrollArea className="h-[200px] w-full rounded-md border p-4 bg-muted">
            <div className="space-y-2 font-mono text-sm">
              <p>[09:42:15] 初始化项目配置...</p>
              <p>[09:42:18] 已选择3D游戏项目类型</p>
              <p>[09:42:20] 已选择Cursor作为代码编辑器</p>
              <p>[09:42:22] 已选择Blender作为建模软件</p>
              <p>[09:42:25] 开始建模分区任务...</p>
              <p>[09:42:30] 正在启动Blender...</p>
              <p>[09:42:35] Blender已启动，开始创建游戏角色模型</p>
              <p>[09:43:10] 正在设计游戏场景环境...</p>
              <p className="text-yellow-500">[09:43:25] 警告: 模型复杂度较高，可能影响游戏性能</p>
              <p>[09:43:40] 继续优化模型...</p>
            </div>
          </ScrollArea>
        </div>

        <div className="space-y-2">
          <h3 className="text-lg font-medium">问题反馈</h3>
          <div className="space-y-4">
            <div className="p-3 rounded-md bg-red-50 border border-red-200">
              <div className="flex items-center justify-between">
                <span className="font-medium text-red-800">错误: 纹理加载失败</span>
                <Badge variant="destructive">未解决</Badge>
              </div>
              <p className="mt-1 text-sm text-red-700">无法加载角色模型的纹理文件，请检查文件路径或格式</p>
            </div>
            
            <div className="p-3 rounded-md bg-yellow-50 border border-yellow-200">
              <div className="flex items-center justify-between">
                <span className="font-medium text-yellow-800">警告: 性能问题</span>
                <Badge variant="outline" className="bg-yellow-100">处理中</Badge>
              </div>
              <p className="mt-1 text-sm text-yellow-700">游戏场景模型过于复杂，可能导致帧率下降</p>
            </div>
            
            <div className="p-3 rounded-md bg-green-50 border border-green-200">
              <div className="flex items-center justify-between">
                <span className="font-medium text-green-800">已解决: 碰撞检测</span>
                <Badge variant="outline" className="bg-green-100">已修复</Badge>
              </div>
              <p className="mt-1 text-sm text-green-700">角色与场景物体的碰撞检测问题已修复</p>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-lg font-medium">提交反馈</h3>
          <Textarea
            placeholder="描述您发现的问题或需要改进的地方..."
            className="min-h-[100px]"
          />
          <div className="flex justify-end">
            <Button>提交反馈</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
