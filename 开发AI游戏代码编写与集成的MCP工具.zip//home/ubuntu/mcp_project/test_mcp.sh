#!/bin/bash

# MCP工具测试脚本
# 用于测试MCP工具的各项功能

echo "开始测试MCP工具..."

# 测试环境变量
export MCP_PORT=7090
export MCP_FRONTEND_DIR="/home/ubuntu/mcp_project/mcp_frontend"
export MCP_BACKEND_DIR="/home/ubuntu/mcp_project/mcp_backend"

# 测试前端构建
echo "测试前端构建..."
cd $MCP_FRONTEND_DIR
npm run build
if [ $? -ne 0 ]; then
  echo "前端构建失败!"
  exit 1
fi
echo "前端构建成功!"

# 测试后端服务器启动
echo "测试后端服务器启动..."
cd $MCP_BACKEND_DIR
node server.js &
SERVER_PID=$!
sleep 2

# 检查服务器是否正常运行
curl -s http://localhost:$MCP_PORT/api/project/list > /dev/null
if [ $? -ne 0 ]; then
  echo "后端服务器启动失败!"
  kill $SERVER_PID
  exit 1
fi
echo "后端服务器启动成功!"

# 测试API端点
echo "测试API端点..."

# 测试项目API
echo "测试项目API..."
curl -s -X POST -H "Content-Type: application/json" -d '{"name":"测试游戏","type":"2d","description":"测试游戏项目"}' http://localhost:$MCP_PORT/api/project/create
if [ $? -ne 0 ]; then
  echo "项目API测试失败!"
  kill $SERVER_PID
  exit 1
fi
echo "项目API测试成功!"

# 测试AI API
echo "测试AI API..."
curl -s -X GET http://localhost:$MCP_PORT/api/ai/models
if [ $? -ne 0 ]; then
  echo "AI API测试失败!"
  kill $SERVER_PID
  exit 1
fi
echo "AI API测试成功!"

# 测试IDE API
echo "测试IDE API..."
curl -s -X GET http://localhost:$MCP_PORT/api/ide/list
if [ $? -ne 0 ]; then
  echo "IDE API测试失败!"
  kill $SERVER_PID
  exit 1
fi
echo "IDE API测试成功!"

# 测试建模API
echo "测试建模API..."
curl -s -X GET http://localhost:$MCP_PORT/api/modeling/software-list
if [ $? -ne 0 ]; then
  echo "建模API测试失败!"
  kill $SERVER_PID
  exit 1
fi
echo "建模API测试成功!"

# 测试AI-IDE集成API
echo "测试AI-IDE集成API..."
curl -s -X POST -H "Content-Type: application/json" -d '{"projectId":"test-project","ideName":"cursor"}' http://localhost:$MCP_PORT/api/ai-ide/init-session
if [ $? -ne 0 ]; then
  echo "AI-IDE集成API测试失败!"
  kill $SERVER_PID
  exit 1
fi
echo "AI-IDE集成API测试成功!"

# 测试项目管理API
echo "测试项目管理API..."
curl -s -X POST -H "Content-Type: application/json" -d '{"name":"测试项目","type":"2d","description":"测试项目描述"}' http://localhost:$MCP_PORT/api/project-manager/create
if [ $? -ne 0 ]; then
  echo "项目管理API测试失败!"
  kill $SERVER_PID
  exit 1
fi
echo "项目管理API测试成功!"

# 停止后端服务器
echo "停止后端服务器..."
kill $SERVER_PID
sleep 2

echo "所有API测试完成!"

# 测试前端页面
echo "测试前端页面..."
cd $MCP_FRONTEND_DIR
npm run dev &
FRONTEND_PID=$!
sleep 5

# 检查前端页面是否正常运行
curl -s http://localhost:3000 > /dev/null
if [ $? -ne 0 ]; then
  echo "前端页面启动失败!"
  kill $FRONTEND_PID
  exit 1
fi
echo "前端页面启动成功!"

# 停止前端服务器
echo "停止前端服务器..."
kill $FRONTEND_PID
sleep 2

echo "所有测试完成!"
echo "MCP工具测试通过!"
