#!/bin/bash

# MCP工具部署脚本
# 用于打包和部署MCP工具

echo "开始打包MCP工具..."

# 环境变量
export MCP_VERSION="1.0.0"
export MCP_FRONTEND_DIR="/home/ubuntu/mcp_project/mcp_frontend"
export MCP_BACKEND_DIR="/home/ubuntu/mcp_project/mcp_backend"
export MCP_DIST_DIR="/home/ubuntu/mcp_project/dist"

# 创建分发目录
mkdir -p $MCP_DIST_DIR

# 构建前端
echo "构建前端..."
cd $MCP_FRONTEND_DIR
npm run build

# 复制前端构建文件到分发目录
echo "复制前端文件..."
mkdir -p $MCP_DIST_DIR/frontend
cp -r $MCP_FRONTEND_DIR/build/* $MCP_DIST_DIR/frontend/

# 准备后端文件
echo "准备后端文件..."
mkdir -p $MCP_DIST_DIR/backend
cp -r $MCP_BACKEND_DIR/* $MCP_DIST_DIR/backend/

# 移除不必要的文件
echo "清理不必要的文件..."
rm -rf $MCP_DIST_DIR/backend/node_modules
rm -rf $MCP_DIST_DIR/backend/tests

# 创建启动脚本
echo "创建启动脚本..."
cat > $MCP_DIST_DIR/start_mcp.sh << 'EOF'
#!/bin/bash

# MCP工具启动脚本

# 设置环境变量
export MCP_PORT=7090
export NODE_ENV=production

# 启动后端服务器
echo "启动MCP后端服务器..."
cd backend
npm install
node server.js &
SERVER_PID=$!

# 等待服务器启动
echo "等待服务器启动..."
sleep 3

# 打开浏览器
echo "打开MCP工具界面..."
if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:$MCP_PORT
elif command -v open &> /dev/null; then
    open http://localhost:$MCP_PORT
elif command -v start &> /dev/null; then
    start http://localhost:$MCP_PORT
fi

echo "MCP工具已启动!"
echo "按Ctrl+C停止服务器"

# 等待用户中断
wait $SERVER_PID
EOF

# 设置启动脚本权限
chmod +x $MCP_DIST_DIR/start_mcp.sh

# 创建安装脚本
echo "创建安装脚本..."
cat > $MCP_DIST_DIR/install.sh << 'EOF'
#!/bin/bash

# MCP工具安装脚本

echo "开始安装MCP工具..."

# 检查Node.js
if ! command -v node &> /dev/null; then
    echo "未检测到Node.js，请先安装Node.js (v14+)"
    exit 1
fi

# 检查npm
if ! command -v npm &> /dev/null; then
    echo "未检测到npm，请先安装npm"
    exit 1
fi

# 安装后端依赖
echo "安装后端依赖..."
cd backend
npm install

echo "MCP工具安装完成!"
echo "使用 ./start_mcp.sh 启动工具"
EOF

# 设置安装脚本权限
chmod +x $MCP_DIST_DIR/install.sh

# 创建README文件
echo "创建README文件..."
cat > $MCP_DIST_DIR/README.md << 'EOF'
# MCP游戏开发工具

MCP是一个专门用于AI编写游戏代码、测试和集成游戏项目的工具。

## 系统要求

- Node.js v14+
- npm v6+
- 现代浏览器（Chrome, Firefox, Edge等）

## 安装

1. 解压MCP工具包
2. 运行安装脚本：`./install.sh`

## 启动

运行启动脚本：`./start_mcp.sh`

## 更多信息

详细使用说明请参考用户手册（user_manual.pdf）
EOF

# 打包分发文件
echo "打包分发文件..."
cd /home/ubuntu/mcp_project
tar -czvf mcp-tool-v$MCP_VERSION.tar.gz -C $MCP_DIST_DIR .

echo "MCP工具打包完成: mcp-tool-v$MCP_VERSION.tar.gz"
